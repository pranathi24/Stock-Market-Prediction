import { Component, OnInit } from '@angular/core';

declare var onValidate: any;

@Component({
  selector: 'app-workshops',
  templateUrl: './workshops.component.html',
  styleUrls: ['./workshops.component.css']
})
export class WorkshopsComponent implements OnInit {

  constructor() { }

  c2:number=0;

  Onlog()
  {
    onValidate();
    this.c2++;
    
  }

  ngOnInit(): void {
  }

}
