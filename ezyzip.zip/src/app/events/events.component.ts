import { Component, OnInit } from '@angular/core';


declare var onValidate: any;


@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent implements OnInit {

  constructor() { }

  c1:number=0;
  log:number=0;
  showLog=false;

  Onlog()
  {
    onValidate();
    this.c1++;

    this.showLog = true;
         return this.log = this.log + 1;
    
  }

  ngOnInit(): void {
  }

}
