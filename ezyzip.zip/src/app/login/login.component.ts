import { Component, OnInit } from '@angular/core';

declare var onValidate: any;

import {NgModule} from '@angular/core';
import { AppRoutingModule } from "../app-routing.module";
import { Router } from '@angular/router';
import {AppComponent } from '../app.component';
import {FormGroup, FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})


export class LoginComponent  {

  constructor() { }

  Onlog()
  {
    onValidate();
    
  }


  // ngOnInit(): void {
  // }

}
